import React, { useEffect, useState } from "react";
import "./PokemonList.css";
import axios from "axios";

export default function PokemonList({ pokemon }) {
  const [pokemonArray, setpokemonArray] = useState([]);

  let tempPokemonArray = [];
  useEffect(() => {
    const getFullNamePokemon = async e => {
      await axios.get(e.url).then(res2 => {
        tempPokemonArray.push({
          ...e,
          pic: res2.data.sprites.front_default
        });
      });
      // if (tempPokemonArray.length === 20)
    };
    
    pokemon.forEach(e => {
      getFullNamePokemon(e);
      // console.log('e',e)
      setpokemonArray(()=>tempPokemonArray)
      
    });
  }, [pokemon]);
  
  console.log(tempPokemonArray);
  

  console.log("poke", pokemonArray);

  return (
    <div>
      {pokemonArray &&
        pokemonArray.map(p => {
          return (
            <div className="pokemon" key={p.name}>
              {p.name}
            </div>
          );
        })}
    </div>
  );
}
